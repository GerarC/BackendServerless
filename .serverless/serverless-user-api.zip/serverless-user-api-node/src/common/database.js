export const USERS = [
    {
        id: 1,
        name: "Gerardo Castillo",
        email: "gerardo.castillo@pragma.com.co"
    },
    {
        id: 2,
        name: "Gloria Morales",
        email: "gloria.morales@email.com"
    },
    {
        id: 3,
        name: "Diego Morales",
        email: "diego.morales@email.com"
    },
    {
        id: 4,
        name: "Carlos Ardila",
        email: "carlos.ardila@email.com"
    },
    {
        id: 5,
        name: "Jesus Jaramillo",
        email: "jesus.jaramillo@email.com"
    },
]