const { USERS } = require("../common/database");

exports.get = async (event) => {
  return {
    statusCode: 200,
    body: JSON.stringify(USERS),
  };
};
