package serverless.challenge.handlers;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import serverless.challenge.dto.response.UserResponse;

public class DeleteUserHandler implements RequestHandler<String, UserResponse> {
    private static final Logger log = LogManager.getLogger(DeleteUserHandler.class);

    @Override
    public UserResponse handleRequest(String id, Context context) {
        log.debug("id: {}", id);
        return new UserResponse(id, "OmeloChino", "soy.como.omelo@pelo.chino");
    }
}