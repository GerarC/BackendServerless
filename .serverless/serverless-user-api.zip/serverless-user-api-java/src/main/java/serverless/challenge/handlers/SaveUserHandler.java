package serverless.challenge.handlers;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import serverless.challenge.dto.request.UserRequest;
import serverless.challenge.dto.response.UserResponse;


public class SaveUserHandler implements RequestHandler<UserRequest, UserResponse> {
    private static final Logger logger = LogManager.getLogger(SaveUserHandler.class);
    public UserResponse saveUser(UserResponse userResponse){
        return userResponse;
    }

    @Override
    public UserResponse handleRequest(UserRequest userRequest, Context context) {
        logger.debug("Hello, user");
        logger.debug("user: {}", userRequest);
        return new UserResponse("1", userRequest.getName(), userRequest.getEmail());
    }
}