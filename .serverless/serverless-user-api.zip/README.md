A basic project made with Java and NodeJs which is deployed into an AWS environment using Serverless Framework.
